CREATE PROCEDURE test_insert()
  BEGIN 
DECLARE a TINYINT DEFAULT 1;
while (a<=234)DO
insert into t_rtu_warning(id)values(a); 
set a= a+1;
END WHILE ; 
commit; 
END;
