CREATE PROCEDURE test_insert4()
  BEGIN 
DECLARE a TINYINT DEFAULT 1;
while (a<=234)DO
insert into t_rtu_warning(id,sn_number,pack_name,pack_traffic,status)values(a,1,1,1,1,'00'); 
set a= a+1;
END WHILE ; 
commit; 
END;
