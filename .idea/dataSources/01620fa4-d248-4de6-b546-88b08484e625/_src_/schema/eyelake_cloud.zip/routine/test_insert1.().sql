CREATE PROCEDURE test_insert1()
  BEGIN 
DECLARE a TINYINT DEFAULT 1;
while (a<=234)DO
insert into t_rtu_warning(id,sn_number)values(a,1); 
set a= a+1;
END WHILE ; 
commit; 
END;
