CREATE PROCEDURE test_insert3()
  BEGIN 
DECLARE a TINYINT DEFAULT 1;
while (a<=234)DO
insert into t_rtu_warning(id,sn_number,pack_name,pack_traffic)values(a,1,1,1); 
set a= a+1;
END WHILE ; 
commit; 
END;
